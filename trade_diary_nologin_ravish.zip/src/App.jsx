
import React, { useEffect, useState, useMemo } from 'react'
import { Line } from 'react-chartjs-2'
import { Chart as ChartJS, CategoryScale, LinearScale, PointElement, LineElement, Tooltip, Legend } from 'chart.js'
ChartJS.register(CategoryScale, LinearScale, PointElement, LineElement, Tooltip, Legend)

const STORAGE_KEY = 'trade_diary_trades_v1'
const CAPITAL_KEY = 'trade_diary_capital_v1'

function sampleTrades(){
  return [
    {id:1,date:'2025-11-01',symbol:'SENSEX',type:'Buy',entry:100000,exit:100500,qty:1,sl:99950,target:100800,setup:'Breakout',emotion:'Calm',remarks:'Sample',reviewed:false},
    {id:2,date:'2025-11-02',symbol:'SENSEX',type:'Sell',entry:100900,exit:100400,qty:1,sl:101000,target:100200,setup:'Scalp',emotion:'Fear',remarks:'Sample2',reviewed:false}
  ]
}

export default function App(){
  const [trades, setTrades] = useState([])
  const [form, setForm] = useState({ date:'', symbol:'SENSEX', type:'Buy', entry:'', exit:'', qty:1, sl:'', target:'', setup:'Breakout', emotion:'Calm', remarks:'', tags:'' })
  const [filter, setFilter] = useState({ symbol:'All', type:'All', setup:'All' })
  const [openingCapital, setOpeningCapital] = useState(4000)

  useEffect(()=>{
    const raw = localStorage.getItem(STORAGE_KEY)
    const cap = localStorage.getItem(CAPITAL_KEY)
    if(cap) setOpeningCapital(Number(cap))
    if(raw){
      try{ setTrades(JSON.parse(raw)) }catch(e){ setTrades(sampleTrades()) }
    } else {
      setTrades(sampleTrades())
    }
  },[])

  useEffect(()=>{
    localStorage.setItem(STORAGE_KEY, JSON.stringify(trades))
  },[trades])

  useEffect(()=>{
    localStorage.setItem(CAPITAL_KEY, String(openingCapital))
  },[openingCapital])

  function addTrade(e){
    e.preventDefault()
    const id = Date.now()
    const t = { id, ...form }
    setTrades(prev=>[t, ...prev])
    setForm({ date:'', symbol:form.symbol, type:'Buy', entry:'', exit:'', qty:1, sl:'', target:'', setup:'Breakout', emotion:'Calm', remarks:'' })
  }

  function removeTrade(id){
    if(!window.confirm('Delete trade?')) return
    setTrades(prev=>prev.filter(t=>t.id!==id))
  }

  function toggleReviewed(id){
    setTrades(prev=>prev.map(t=> t.id===id ? {...t, reviewed: !t.reviewed} : t))
  }

  function exportCSV(){
    if(trades.length===0){ alert('No trades to export'); return }
    const esc = s => '\"'+String(s??'').replace(/\"/g,'""')+'\"'
    const header = ['Date','Symbol','Type','Entry','Exit','Qty','SL','Target','Setup','Emotion','Remarks','Tags']
    const rows = trades.map(t=> [t.date,t.symbol,t.type,t.entry,t.exit,t.qty,t.sl,t.target,t.setup,t.emotion,t.remarks,t.tags||''].map(esc).join(','))
    const csv = header.join(',') + '\\n' + rows.join('\\n')
    const blob = new Blob([csv], {type:'text/csv;charset=utf-8;'})
    const link = document.createElement('a'); link.href=URL.createObjectURL(blob); link.download='trades_export.csv'; document.body.appendChild(link); link.click(); link.remove()
  }

  function importCSV(file){
    const reader = new FileReader()
    reader.onload = e => {
      const text = e.target.result
      const lines = text.split('\\n').map(l=>l.trim()).filter(Boolean)
      const [h,...rows] = lines
      const cols = h.split(',').map(s=>s.replace(/\"/g,'').trim())
      const newTrades = rows.map((r,i)=>{
        const vals = r.split(',').map(v=>v.replace(/\"/g,''))
        const obj = {}
        cols.forEach((c,idx)=> obj[c]=vals[idx])
        return { id: Date.now()+i, date:obj.Date, symbol: obj.Symbol||'SENSEX', type: obj.Type||'Buy', entry: Number(obj.Entry)||0, exit: Number(obj.Exit)||0, qty: Number(obj.Qty)||1, sl: obj.SL||'', target: obj.Target||'', setup: obj.Setup||'Breakout', emotion: obj.Emotion||'Calm', remarks: obj.Remarks||'', tags: obj.Tags||'', reviewed:false }
      })
      setTrades(prev=>[...newTrades, ...prev])
    }
    reader.readAsText(file)
  }

  const filtered = trades.filter(t=> (filter.symbol==='All'||t.symbol===filter.symbol) && (filter.type==='All'||t.type===filter.type) && (filter.setup==='All'||t.setup===filter.setup))

  const pnlSum = trades.reduce((s,t)=> s + ((Number(t.exit)||0) - (Number(t.entry)||0)) * (Number(t.qty)||1), 0)
  const closingCapital = openingCapital + pnlSum

  // simple equity chart: by date (group)
  const eqByDate = {}
  trades.slice().reverse().forEach(t=>{
    const d = t.date || new Date(t.id).toISOString().slice(0,10)
    const p = ((Number(t.exit)||0) - (Number(t.entry)||0)) * (Number(t.qty)||1)
    eqByDate[d] = (eqByDate[d]||0) + p
  })
  const labels = Object.keys(eqByDate)
  const cumulative = []
  let acc = 0
  labels.forEach(l=> { acc += eqByDate[l]; cumulative.push(acc + openingCapital) })

  const chartData = { labels, datasets: [{ label:'Equity', data:cumulative, fill:false, borderColor:'#2563eb' }] }

  return (
    <div className="container">
      <header className="header">
        <h1>Trade Diary — Local (No Login)</h1>
        <div className="small">Trades saved in browser storage • Export / Import CSV</div>
      </header>

      <section className="card">
        <h3>Capital Tracker</h3>
        <div className="flex">
          <div>Opening Capital ₹</div>
          <input type="number" value={openingCapital} onChange={e=>setOpeningCapital(Number(e.target.value))} />
          <div className="right small">Closing Capital: ₹{closingCapital.toFixed(2)}</div>
        </div>
      </section>

      <section className="card" style={{display:'grid',gridTemplateColumns:'1fr 380px',gap:12}}>
        <div>
          <h3>Add / Edit Trade</h3>
          <form onSubmit={addTrade} style={{display:'grid',gap:8}}>
            <input placeholder="Date (YYYY-MM-DD)" value={form.date} onChange={e=>setForm({...form,date:e.target.value})} />
            <input placeholder="Symbol" value={form.symbol} onChange={e=>setForm({...form,symbol:e.target.value})} />
            <select value={form.type} onChange={e=>setForm({...form,type:e.target.value})}><option>Buy</option><option>Sell</option></select>
            <input placeholder="Entry Price" value={form.entry} onChange={e=>setForm({...form,entry:e.target.value})} />
            <input placeholder="Exit Price" value={form.exit} onChange={e=>setForm({...form,exit:e.target.value})} />
            <input placeholder="Qty" value={form.qty} onChange={e=>setForm({...form,qty:e.target.value})} />
            <input placeholder="Stop Loss" value={form.sl} onChange={e=>setForm({...form,sl:e.target.value})} />
            <input placeholder="Target" value={form.target} onChange={e=>setForm({...form,target:e.target.value})} />
            <select value={form.setup} onChange={e=>setForm({...form,setup:e.target.value})}><option>Breakout</option><option>Pullback</option><option>Reversal</option><option>Scalp</option></select>
            <select value={form.emotion} onChange={e=>setForm({...form,emotion:e.target.value})}><option>Calm</option><option>Fear</option><option>Greed</option><option>Impulse</option></select>
            <input placeholder="Tags (comma separated)" value={form.tags} onChange={e=>setForm({...form,tags:e.target.value})} />
            <textarea placeholder="Remarks" value={form.remarks} onChange={e=>setForm({...form,remarks:e.target.value})} />
            <div style={{display:'flex',gap:8}}>
              <button type="submit">Add Trade</button>
              <button type="button" onClick={()=>{ setTrades([]); localStorage.removeItem(STORAGE_KEY) }}>Clear All</button>
              <button type="button" onClick={()=>exportCSV()}>Export CSV</button>
            </div>
          </form>
        </div>

        <aside>
          <h3>Import / Filters</h3>
          <div className="small">Import CSV (Date,Symbol,Type,Entry,Exit,Qty,SL,Target,Setup,Emotion,Remarks)</div>
          <input type="file" accept=".csv" onChange={e=>importCSV(e.target.files[0])} />
          <hr />
          <div style={{marginTop:8}}>
            <label>Symbol</label><br />
            <select value={filter.symbol} onChange={e=>setFilter({...filter,symbol:e.target.value})}><option>All</option>{Array.from(new Set(trades.map(t=>t.symbol))).map(s=> <option key={s}>{s}</option>)}</select><br />
            <label>Type</label><br />
            <select value={filter.type} onChange={e=>setFilter({...filter,type:e.target.value})}><option>All</option><option>Buy</option><option>Sell</option></select><br />
            <label>Setup</label><br />
            <select value={filter.setup} onChange={e=>setFilter({...filter,setup:e.target.value})}><option>All</option><option>Breakout</option><option>Pullback</option><option>Reversal</option><option>Scalp</option></select>
          </div>
          <hr />
          <h4 className="small">Weekly Summary</h4>
          <div className="small">
            {trades.length===0 && <div>No trades</div>}
            {trades.length>0 && (
              <div>
                <div>Total trades: {trades.length}</div>
                <div>Net P&L: ₹{pnlSum.toFixed(2)}</div>
                <div>Winning %: { (trades.filter(t=> ((Number(t.exit)||0)-(Number(t.entry)||0))*(Number(t.qty)||1) >0).length / trades.length *100).toFixed(0) }%</div>
              </div>
            )}
          </div>
        </aside>
      </section>

      <section className="card">
        <h3>Trades</h3>
        <table className="table">
          <thead><tr><th>Date</th><th>Symbol</th><th>Type</th><th>Entry</th><th>Exit</th><th>Qty</th><th>P&L</th><th>Setup</th><th>Emotion</th><th>Tags</th><th>R</th><th>Actions</th></tr></thead>
          <tbody>
            {filtered.map(t=> {
              const pnl = ((Number(t.exit)||0)-(Number(t.entry)||0))*(Number(t.qty)||1)
              const r = (Number(t.entry) && Number(t.sl)) ? Math.abs(((Number(t.exit)||0)-(Number(t.entry)||0))/((Number(t.entry)||0)-(Number(t.sl)||0))) : ''
              return (<tr key={t.id}><td>{t.date}</td><td>{t.symbol}</td><td>{t.type}</td><td>{t.entry}</td><td>{t.exit}</td><td>{t.qty}</td><td>₹{pnl.toFixed(2)}</td><td>{t.setup}</td><td>{t.emotion}</td><td>{t.tags||''}</td><td>{r? r.toFixed(2):''}</td><td><button onClick={()=>toggleReviewed(t.id)}>{t.reviewed?'Reviewed':'Review'}</button> <button onClick={()=>removeTrade(t.id)}>Delete</button></td></tr>) }) }
          </tbody>
        </table>
      </section>


      <section className="card">
        <h3>Performance Dashboard</h3>
        <div className="small">
          <div>Total Trades: <strong>{trades.length}</strong></div>
          <div>Winning Trades: <strong>{ (trades.filter(t=> ((Number(t.exit)||0)-(Number(t.entry)||0))*(Number(t.qty)||1) >0).length) }</strong></div>
          <div>Win Rate: <strong>{ trades.length ? (trades.filter(t=> ((Number(t.exit)||0)-(Number(t.entry)||0))*(Number(t.qty)||1) >0).length / trades.length *100).toFixed(1) : '0' }%</strong></div>
          <div>Average P&L per Trade: <strong>₹{ trades.length ? ( (trades.reduce((s,t)=> s + ((Number(t.exit)||0)-(Number(t.entry)||0))*(Number(t.qty)||1),0)) / trades.length ).toFixed(2) : '0.00' }</strong></div>
          <div>Largest Win: <strong>₹{ trades.length ? Math.max(...trades.map(t=> ((Number(t.exit)||0)-(Number(t.entry)||0))*(Number(t.qty)||1))) : 0 }</strong></div>
          <div>Largest Loss: <strong>₹{ trades.length ? Math.min(...trades.map(t=> ((Number(t.exit)||0)-(Number(t.entry)||0))*(Number(t.qty)||1))) : 0 }</strong></div>
        </div>
      </section>
    
      <section className="card">
        <h3>Equity Chart</h3>
        {labels.length===0 ? <div className="small">No data</div> : <Line data={chartData} />}
      </section>

      <footer className="card small" style={{textAlign:'center',marginTop:20}}>This is a local no-login Trade Diary. Your data stays in this browser's local storage. You can export CSV to keep backups.</footer>
    </div>
  )
}
