
# Trade Diary (No Login) - Starter

This is a minimal React + Vite project implementing a **local, no-login trade diary** app.
Features:
- Add trades with dropdowns (Setup, Emotion, etc.)
- Save trades in browser localStorage (no server)
- Import / Export CSV
- Simple equity chart
- Capital tracker & weekly summary
- Mobile-friendly single-file React app

## Run locally
1. Install Node.js and npm.
2. In project folder run:
   npm install
   npm run dev
3. Open http://localhost:5173

## Files
- index.html
- package.json
- src/main.jsx
- src/App.jsx
- src/index.css
- example_trades.csv

Your data is stored in browser localStorage. Use Export CSV to backup.
